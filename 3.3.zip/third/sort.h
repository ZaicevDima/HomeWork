#ifndef SORT_H
#define SORT_H

void sort(int size, int* array);

#endif
