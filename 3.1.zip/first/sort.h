#ifndef SORT_H
#define SORT_H

void sort(int length, int* array);

#endif
