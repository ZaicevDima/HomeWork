#ifndef STRINGSORT_H
#define STRINGSORT_H

void sort(int size, char* array);

#endif
